package com.example.bestbanho

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
